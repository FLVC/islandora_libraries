jsTree pre1.0
http://jstree.com/

Copyright (c) 2011 Ivan Bozhanov (vakata.com)

Dual licensed under the MIT and GPL licenses:
  http://www.opensource.org/licenses/mit-license.php
  http://www.gnu.org/licenses/gpl.html

This is the latest stable version before switching from GoogleCode to GitHub.